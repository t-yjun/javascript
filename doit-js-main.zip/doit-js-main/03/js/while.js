let stars = parseInt(prompt("별의 갯수 : "));

while(stars > 0) {
  document.write('*');
  stars--;
}