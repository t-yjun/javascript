const students = ["Park", "Kim", "Lee", "Kang"];

// students에 있는 student가 있는 동안 계속 반복
for (let student of students) {  
  document.write(`${student}. `);
}