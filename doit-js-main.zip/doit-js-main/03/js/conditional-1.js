let userInput = prompt("이름을 입력하세요.");
if(userInput === null) {
  alert("취소했습니다.");
} else {
  alert(userInput);
}