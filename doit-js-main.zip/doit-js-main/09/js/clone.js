const bag1 = {
  color: "blue",
  width:30,
  height: 50
}

const bag2 = { ...bag1};