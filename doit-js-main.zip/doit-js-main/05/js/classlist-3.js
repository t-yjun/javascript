const title = document.querySelector("#title");

title.onclick = () => {
  title.classList.toggle("clicked");
}
