const title = document.querySelector("#title");

title.onclick = () => {
  title.style.backgroundColor = "black";
  title.style.color = "white";
};
