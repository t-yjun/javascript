window.open("notice.html", "", "width=600 height=500")
