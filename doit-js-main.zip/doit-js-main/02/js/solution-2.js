// 1inch = 2.54cm

let inchValue = parseFloat(prompt("인치 값을 입력하세요."));
let cmValue = inchValue * 2.54;
alert(`${inchValue}인치는 ${cmValue}cm 입니다.`);