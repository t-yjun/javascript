var x = 10;
var sum = x + y;
var y = 20;
console.log(sum);