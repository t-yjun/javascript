const button = document.querySelector("button");

button.onclick = function() {
  document.body.style.backgroundColor = "green";
}