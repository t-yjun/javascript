function changeBackground() {
  document.body.style.backgroundColor = "green";
}
const button = document.querySelector("button");
button.onclick = changeBackground;